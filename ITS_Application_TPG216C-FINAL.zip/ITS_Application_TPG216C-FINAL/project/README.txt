Open VS Code & select the file option in the top left. Navigate to where the project is located, ensuring that the path is correct.

Open a new terminal if one is not already available. 

In the terminal make sure again that the path is corresponding with that which you have on your PC. Then type the following to run the program: dart run main.dart

Navigate the program according to the prompts seen in the terminal to go through the program.
