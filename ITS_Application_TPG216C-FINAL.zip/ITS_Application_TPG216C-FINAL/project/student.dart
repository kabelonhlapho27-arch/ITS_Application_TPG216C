// Mlungisi Njoko 224037409
// Philasande Simelane 224042163
// Mobakeng Mochwaro 224069913
// Nathaniel Stanley 223068452
// Owami Maphalala 224136508
// Kabelo Nhlapo 224002222
// Kyle van Aswegen 220048471

import 'person.dart';

class Student extends Person {
  //field
  String _studentID;

  Student(this._studentID, String firstName, String lastName, String cellphone)
    : super(firstName, lastName, cellphone);

  //Getter
  String get studentID {
    return _studentID;
  }

  //Setter
  set studentID(String studentID) {
    this._studentID = studentID;
  }
}
